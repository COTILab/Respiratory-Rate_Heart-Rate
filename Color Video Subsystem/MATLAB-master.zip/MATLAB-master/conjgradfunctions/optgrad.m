function options = optgrad
options = zeros(1,18);
options (1)=1;
options (7)=1;
options(9)=1;
options(14)=20;