function ca
close all
