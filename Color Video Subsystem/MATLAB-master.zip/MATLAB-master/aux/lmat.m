% Lists m-files. 
ls -lrt *.mat