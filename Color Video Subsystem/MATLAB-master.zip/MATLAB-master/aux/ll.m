% long list of the files in reverse time order
ls -lrt