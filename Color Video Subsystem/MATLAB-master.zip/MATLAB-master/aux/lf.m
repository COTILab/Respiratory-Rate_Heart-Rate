% Lists files only (not directories).
system('ls -l | egrep -v ''^d''');

