function setfotnsizefigure(fontsize)
set(get(gca,'XLabel'),'FontSize',fontsize)
set(get(gca,'YLabel'),'FontSize',fontsize)
set(gca,'FontSize',fontsize)