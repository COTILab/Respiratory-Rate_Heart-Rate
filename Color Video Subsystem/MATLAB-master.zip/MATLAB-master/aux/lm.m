% Lists m-files. 
ls -lrt *.m