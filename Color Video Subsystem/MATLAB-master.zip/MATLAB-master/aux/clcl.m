function clcl
close all
clear all
clc
