R = input ('Clear data? [y/n] \n','s');
if strcmp(R,'y')
    clear
end
