% Lists directories. 
system('ls -l | egrep ''^d''');