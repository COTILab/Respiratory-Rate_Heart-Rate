function y = linearFunction(x,p)
% Linear funciton. 
% y = linearFunction(x,p);
y = p(1)*x+p(2);