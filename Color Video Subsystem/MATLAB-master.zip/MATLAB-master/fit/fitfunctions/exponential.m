function f = exponential(x,p)
% f = exponential(x,p)
% Function p(1)*exp(p(2)*x)+p(3)
f = p(1)*exp(p(2)*x)+p(3);



